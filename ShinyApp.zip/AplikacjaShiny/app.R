library(shiny)
library(shinydashboard)
library(shinythemes)
library(readxl)
library(dplyr)
library(ggplot2)

file_path <- "Salary.xlsx"
salary <- readxl::read_excel(file_path) %>%
  dplyr::select(-4)
salary$Wiek <- as.integer(salary$Wiek)

get_stats <- function(data, variables) {
  lapply(variables, function(var) {
    if (is.numeric(data[[var]])) {
      summary(data[[var]])
    } else {
      table(data[[var]])
    }
  })
}

anova_analysis <- function(data) {
  anova_result <- aov(`Roczne wynagrodzenie` ~ ., data = data)
  return(summary(anova_result))
}

ui <- dashboardPage(
  dashboardHeader(title = "Aplikacja Shiny"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Wykres", tabName = "plot_tab"),
      menuItem("Statystyki", tabName = "stats_tab"),
      menuItem("Analiza wariancji", tabName = "anova_tab")
    )
  ),
  dashboardBody(
    tabItems(
      tabItem(tabName = "plot_tab",
              fluidPage(
                selectInput("plot_type", "Wybierz typ wykresu",
                            choices = c("Wykres punktowy" = "point", "Histogram" = "histogram", "Wykres z wąsami" = "boxplot")),
                conditionalPanel(
                  condition = "input.plot_type == 'histogram'",
                  selectInput("histogram_variable", "Wybierz zmienną do histogramu", 
                              choices = names(salary[sapply(salary, is.numeric)])),
                  sliderInput("bins", "Liczba słupków na histogramie", min = 1, max = 40, value = 10)
                ),
                conditionalPanel(
                  condition = "input.plot_type == 'point' || input.plot_type == 'boxplot'",
                  selectInput("x_variable", "Wybierz zmienną X", choices = names(salary)),
                  selectInput("y_variable", "Wybierz zmienną Y", choices = names(salary))
                ),
                actionButton("plot_button", "Generuj wykres"),
                plotOutput("custom_plot")
              )
      ),
      tabItem(tabName = "stats_tab",
              fluidPage(
                selectInput("stats_variable", "Wybierz zmienną do statystyk", 
                            choices = names(salary)),
                actionButton("stats_button", "Generuj statystyki"),
                verbatimTextOutput("summary_text")
              )
      ),
      tabItem(tabName = "anova_tab",
              fluidPage(
                selectInput("anova_variable", "Wybierz zmienną do analizy wariancji", 
                            choices = names(salary)),
                actionButton("anova_button", "Analiza wariancji dla Roczne wynagrodzenie"),
                verbatimTextOutput("anova_test_result"),
                verbatimTextOutput("anova_text"),
                verbatimTextOutput("kruskal_result")
              )
      )
    )
  )
)

server <- function(input, output, session) {
  data <- reactiveValues(
    plot_data = NULL,
    summary_data = NULL,
    anova_data = NULL
  )
  
  observe({
    updateSelectInput(session, "histogram_variable", choices = names(salary[sapply(salary, is.numeric)]))
    updateSelectInput(session, "x_variable", choices = names(salary))
    updateSelectInput(session, "y_variable", choices = names(salary))
    updateSelectInput(session, "stats_variable", choices = names(salary))
    updateSelectInput(session, "anova_variable", choices = names(salary))
    
    # Wyczyszczenie komunikatów przy każdym nowym wyborze zmiennej
    output$anova_test_result <- renderPrint(NULL)
    output$anova_text <- renderPrint(NULL)
    output$summary_text <- renderPrint(NULL)
    output$kruskal_result <- renderPrint(NULL)
  })
  
  observeEvent(c(input$x_variable, input$y_variable, input$histogram_variable, input$bins), {
    output$anova_test_result <- renderPrint(NULL)
    output$anova_text <- renderPrint(NULL)
    output$summary_text <- renderPrint(NULL)
    output$kruskal_result <- renderPrint(NULL)
    if (input$plot_type == "point") {
      x <- input$x_variable
      y <- input$y_variable
      
      data$plot_data <- ggplot(salary, aes(x = !!sym(x), y = !!sym(y))) +
        geom_point(color = "blue", size = 3) +
        labs(title = paste("Wykres punktowy dla", x, "i", y)) +
        theme_minimal()
      
      data$summary_data <- get_stats(salary, c(x, y))
    } else if (input$plot_type == "histogram") {
      histogram_var <- input$histogram_variable
      bins <- input$bins
      
      data$plot_data <- ggplot(salary, aes(x = !!sym(histogram_var))) +
        geom_histogram(bins = bins, fill = "orange", color = "black") +
        labs(title = paste("Histogram dla", histogram_var)) +
        theme_minimal()
      
      data$summary_data <- get_stats(salary, histogram_var)
    } else if (input$plot_type == "boxplot") {
      x <- input$x_variable
      y <- input$y_variable
      
      data$plot_data <- ggplot(salary, aes(x = !!sym(x), y = !!sym(y))) +
        geom_boxplot(fill = "lightblue", color = "blue") +
        labs(title = paste("Wykres z wąsami dla", x, "i", y)) +
        theme_minimal()
      
      data$summary_data <- get_stats(salary, c(x, y))
    }
  })
  
  observeEvent(input$plot_button, {
    output$custom_plot <- renderPlot({
      data$plot_data
    })
    
    output$summary_text <- renderPrint({
      if (!is.null(data$summary_data)) {
        lapply(data$summary_data, function(var_data) {
          if (!is.null(var_data)) {
            var_data
          }
        })
      } else {
        "Brak statystyk."
      }
    })
  })
  
  observeEvent(c(input$stats_variable, input$stats_button), {
    stats_var <- input$stats_variable
    data$summary_data <- get_stats(salary, stats_var)
  })
  
  observeEvent(input$anova_button, {
    anova_var <- input$anova_variable
    anova_data <- salary[[anova_var]]
    
    # Wyczyszczenie komunikatów przed przeprowadzeniem nowego testu
    output$anova_test_result <- renderPrint(NULL)
    output$anova_text <- renderPrint(NULL)
    output$kruskal_result <- renderPrint(NULL)  # Dodane okno dla wyników testu Kruskala-Wallisa
    
    if (is.numeric(anova_data)) {
      truncated_data <- anova_data[1:min(4999, length(anova_data))]
      shapiro_result <- shapiro.test(truncated_data)
      
      output$anova_test_result <- renderPrint({
        paste("Test Shapiro-Wilka dla", anova_var, ": p-value =", shapiro_result$p.value)
      })
      
      if (shapiro_result$p.value > 0.05) {
        data$anova_data <- anova_analysis(salary[, c(anova_var, "Roczne wynagrodzenie")])
      } else {
        output$anova_text <- renderPrint({
          paste("Nie można przeprowadzić analizy wariancji, ponieważ test Shapiro-Wilka wskazał,",
                "że rozkład danych nie jest normalny (p-value <= 0.05). Wykonuję test Kruskala-Wallisa.")
        })
        data$anova_data <- NULL
        
        # Wykonaj test Kruskala-Wallisa
        kruskal_result <- kruskal.test(anova_data ~ salary$`Roczne wynagrodzenie`)
        output$kruskal_result <- renderPrint({
          paste("Test Kruskala-Wallisa: p-value =", kruskal_result$p.value)
        })
      }
    } else {
      kruskal_result <- kruskal.test(anova_data ~ salary$`Roczne wynagrodzenie`)
      output$anova_test_result <- renderPrint({
        paste("Wybrana zmienna", anova_var, "nie jest numeryczna. Test Kruskala-Wallisa: p-value =", kruskal_result$p.value)
      })
      data$anova_data <- NULL
    }
  })
  
  
  
  output$anova_text <- renderPrint({
    req(data$anova_data)
    if (!is.null(data$anova_data)) {
      data$anova_data
    } else {
      "Nie spełniono warunku normalności dla analizy wariancji. Nie można przeprowadzić analizy."
    }
  })
}

shinyApp(ui, server)

